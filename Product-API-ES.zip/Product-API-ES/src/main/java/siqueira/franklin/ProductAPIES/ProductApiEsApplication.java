package siqueira.franklin.ProductAPIES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApiEsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApiEsApplication.class, args);
	}

}
