package siqueira.franklin.ProductAPIES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductApiEsApplicationTests {

	@Test
	void contextLoads() {
	}

}
